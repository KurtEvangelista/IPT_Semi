<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Edit</title>
	
	<link rel="stylesheet" href="<?php echo base_url('assets/css/dashboard.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
	<nav class="navbar navbar-dark bg-dark">
	<div class="container">
		<a class="text-muted nav-link fs-4" href="<?php echo base_url('sample/index')?>">Code Igniter</a>
		<div class="d-flex">
			
		</div>
	</div>
</nav>

<!-- section -->

	<div class="sec">
		
	</div>

<!-- end of section -->


<!-- form -->
	<div class="form">
		<div class="container">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="col-md-12">
                        <h3 class="text-left modal-title fw-bold">Update</h3>
                    </div>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url('sample/update') ?>" method="POST" autocomplete="off" class="form-group">
                        <input id="id" type="hidden" name="id" placeholder="First Name"  value="<?php echo $tbl_data->id; ?>">
                        <div class="mb-7">
                            <label for="" class="form-label">
                                First Name:
                            </label>
                    
                            <input id="fname" type="text" name="fname" placeholder="First Name" class="form-control" value="<?php echo $tbl_data->fname; ?>" required>

                        </div>
                         <div class="mb-7">
                            <label for="" class="form-label">
                                Last Name:
                            </label>
                            <input id="lname" type="text" name="lname" placeholder="Last Name" class="form-control"  value="<?php echo $tbl_data->lname; ?>" required>
				
                        </div>
                         <div class="mb-7" class="form-label">
                            <label for="">
                               Email:
                            </label>
                            <input id="user" type="text" name="email" placeholder="Email" class="form-control" value="<?php echo $tbl_data->email ?>" required>
                        </div>
                        <br>
                        <div class="col-md-12" class="form-label">
                            <button type="submit" name="register" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                     <span id="close"><i class="fas fa-times"></i></span>
                </div>
            </div>
        </div>
	</div>
	<!-- end of form -->

	<script type="text/javascript">
		
		function back(){
			alert("back");
		}


	</script>

	
</body>
</html>